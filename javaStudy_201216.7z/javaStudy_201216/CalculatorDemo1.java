package TutorialPackage;


//public class CalculatorDemo1 {
//	
//	public static void main(String[] avgs) {
//		
//		Calculator c1 = new Calculator();
//		c1.sum();
//		c1.avg();
//		
//		Calculator c2 = new Calculator();
//		c2.sum();
//		c2.avg();
//		
//	}
//}
