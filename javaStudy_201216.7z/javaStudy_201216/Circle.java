package TutorialPackage;

//public class Circle {
//	
//	int radius;
//	String name;
//	
//	public Circle() {
//		radius = 1; name = "";
//	}
//	
//	public Circle(int r, String n) {
//		radius = r;
//		name = n;
//	}
//	
//	public double getArea() {
//		return 3.14 * radius * radius;
//	}
//	
//	public static void main(String[] args) {
//		Circle pizza = new Circle(10, "�ڹ�����");
//		
//		double area = pizza.getArea();
//		System.out.println(pizza.name + "�� ������ " + area);
//		
//		Circle donut = new Circle();
//		donut.name = "��������";
//		area = donut.getArea();
//		System.out.println(donut.name + "�� ������ " + area);
//	}
//}

//public class Circle {
//	
//	int radius;
//	String name;
//	
//	public Circle() {
//	}
//	
//	public double getArea() {
//		return 3.14 * radius * radius;
//	}
//	
//	public static void main(String[] args) {
//		Circle pizza;
//		pizza = new Circle();
//		pizza.radius = 10;
//		pizza.name = "�ڹ�����";
//		double area = pizza.getArea();
//		System.out.println(pizza.name + "�� ������ " + area);
//		
//		Circle donut = new Circle();
//		donut.radius = 2;
//		donut.name = "�ڹٵ���";
//		area = donut.getArea();
//		System.out.println(donut.name + "�� ������ " + area);
//	}
//	
//}

//public class Circle {
//	
//	int radius;
//	String name;
//	
//	public Circle() {
//	}
//	
//	public double getArea() {
//		return 3.14 * radius * radius;
//	}
//	
//	public static void main(String[] args) {
//		Circle pizza;
//		pizza = new Circle();
//		pizza.radius = 10;
//		pizza.name = "�ڹ�����";
//		double area = pizza.getArea();
//		System.out.println(pizza.name + "�� ������ " + area);
//		
//		Circle donut;
//		donut = new Circle();
//		donut.radius = 2;
//		donut.name = "�ڹٵ���";
//		area = donut.getArea();
//		System.out.println(donut.name + "�� ������ " + area);
//	}
//}

//public class Circle {
//	
//	int radius;
//	String name;
//	
//	public Circle() {
//	}
//	
//	public double getArea() {
//		return 3.14 * radius * radius;
//	}
//	
//	public static void main(String[] args) {
//		Circle pizza = new Circle();
//		pizza.radius = 10;
//		pizza.name = "�ڹ�����";
//		double area = pizza.getArea();
//		System.out.println(pizza.name + "�� ������ " + area);
//		
//		Circle donut = new Circle();
//		donut.radius = 2;
//		donut.name = "�ڹٵ���";
//		area = donut.getArea();
//		System.out.println(donut.name + "�� ������ " + area);
//		
//	}
//	
//}

//public class Circle {
//	
//	int radius;
//	String name;
//	
//	public Circle() {
//		radius = 1;
//		name = "";
//	}
//	
//	public Circle(int r, String n) {
//		radius = r;
//		name = n;
//	}
//	
//	public double getArea() {
//		return 3.14 * radius * radius ;
//	}
//	
//	public static void main (String[] args) {
//		
//		Circle pizza = new Circle(10, "�ڹ�����");
//		
//		double area = pizza.getArea();
//		System.out.println(pizza.name + "�� ������ " + area);
//		
//		Circle donut = new Circle();
//		donut.name = "��������";
//		area = donut.getArea();
//		System.out.println(donut.name + "�� ������ " + area);
//	}
//}

//public class Circle {
//	int radius;
//	String name;
//	public Circle() {
//		radius = 1;
//		name = "";
//	}
//	public Circle(int r, String n) {
//		radius = r;
//		name = n;
//	}
//	public double getArea() {
//		return 3.14 * radius * radius;
//	}
//	
//	public static void main (String[] args) {
//		Circle pizza = new Circle(10, "�ڹ�����");
//		double area = pizza.getArea();
//		System.out.println(pizza.name + "�� ������ " + area);
//		
//		Circle donut = new Circle();
//		donut.name = "��������";
//		area = donut.getArea();
//		System.out.println(donut.name + "�� ������ " + area);
//	}
//}

//public class Circle {
//	int radius;
//	String name;
//	public Circle() {
//		radius = 1;
//		name = "";
//	}
//	public Circle(int r, String n) {
//		radius = r;
//		name = n;
//	}
//	public double getArea() {
//		return 3.14 * radius * radius;
//	}
//	public static void main (String[] args) {
//		Circle pizza = new Circle(10, "�ڹ�����");
//		double area = pizza.getArea();
//		System.out.println(pizza.name + "�� ������ " + area);
//		
//		Circle donut = new Circle();
//		area = donut.getArea();
//		System.out.println(donut.name + "�� ������ " + area);
//	}
//}

//public class Circle {
//	int radius;
//	void set(int r) { radius = r; }
//	double getArea() { return 3.14*radius*radius; }
//	
//	public static void main (String[] args) {
//		Circle pizza = new Circle();
//		pizza.set(3);
//	}
//}

//public class Circle {
//	int radius;
//	public Circle (int radius) {
//		this.radius = radius;
//	}
//	public void set (int radius) {
//		this.radius = radius;
//	}
//	public static void main(String[] args) {
//		Circle ob1 = new Circle(1);
//		Circle ob2 = new Circle(2);
//		Circle ob3 = new Circle(3);
//		
//		ob1.set(4);
//		ob2.set(5);
//		ob3.set(6);
//	}
//}

//public class Circle {
//	int radius;
//	public Circle (int radius) {
//		this.radius = radius;
//	}
//	public void set (int radius) {
//		this.radius = radius;
//	}
//	public static void main (String[] args) {
//		Circle od1 = new Circle(1) ;
//		Circle od2 = new Circle(2) ;
//		Circle s;
//		
//		s = od2;
//		od1 = od2;
//		System.out.println("od1.radius = " + od1.radius);
//		System.out.println("od2.radius = " + od2.radius);
//	}
//}

//class Circle {
//	int radius;
//	public Circle (int radius) {
//		this.radius = radius;
//	}
//	public double getArea() {
//		return 3.14*radius*radius;
//	}
//}

//class Circle {
//	int radius;
//	public Circle (int radius) {
//		this.radius = radius;
//	}
//	public double getArea() {
//		return 3.14*radius*radius;
//	}
//} 






























 