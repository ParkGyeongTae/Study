package TutorialPackage;

//public class Book {
//	String title;
//	String author;
//	public Book(String t) {
//		title = t;
//		author = "���ڹ̻�";
//	}
//	public Book(String t, String a) {
//		title = t;
//		author = a;
//	}
//	public static void main (String[] args) {
//		Book littlePrince = new Book("�����", "�������丮");
//		Book loveStory = new Book("������");
//		System.out.println(littlePrince.title + " " + littlePrince.author);
//		System.out.println(loveStory.title + " " + loveStory.author);
//	}
//}

//public class Book {
//	String title, author;
//	public Book (String t) {
//		title = t;
//		author = "���ڹ̻�";
//	}
//	public Book (String t, String a) {
//		title = t;
//		author = a;
//	}
//	public static void main (String[] args) {
//		Book littlePrince = new Book("�����", "�������丮");
//		Book loveStory = new Book("������");
//		System.out.println(littlePrince.title + " " + littlePrince.author);
//		System.out.println(loveStory.title + " " + loveStory.author);
//	}
//}

//public class Book {
//	String title, author;
//	public Book (String t) {
//		title = t;
//		author = "�۰��̻�";
//	}
//	public Book (String t, String a) {
//		title = t;
//		author = a;
//	}
//	public static void main (String[] args) {
//		Book littlePrince = new Book("�����", "�������丮");
//		Book loveStory = new Book("������");
//		System.out.println(littlePrince.title + " " + littlePrince.author);
//		System.out.println(loveStory.title + " " + loveStory.author);	
//	}
//}

//class Book {
//	String title, author;
//	public Book(String title, String author) {
//		this.title = title;
//		this.author = author;
//	}
//}

//class Book {
//	String title, author;
//	public Book(String title, String author) {
//		this.title = title;
//		this.author = author;
//	}
//}















